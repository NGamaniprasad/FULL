// Updating active link on navbar
document.querySelector('.active').classList.remove('active');
document.querySelector('a[href="/contact"]').classList.add('active');